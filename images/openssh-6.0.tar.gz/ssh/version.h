/* $OpenBSD: version.h,v 1.64 2012/02/09 20:00:18 markus Exp $ */

#define SSH_VERSION	"OpenSSH_6.0"
